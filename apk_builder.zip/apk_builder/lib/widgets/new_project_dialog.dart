import 'package:flutter/material.dart';

import '../models.dart';
import '../services/github_api.dart';
import '../services/project_store.dart';

/// نافذة «مشروع جديد»: تأخذ الاسم وتنشئ المستودع على GitHub مباشرة.
class NewProjectDialog extends StatefulWidget {
  const NewProjectDialog({
    super.key,
    required this.api,
    required this.owner,
    required this.store,
  });

  final GithubApi api;
  final String owner;
  final ProjectStore store;

  @override
  State<NewProjectDialog> createState() => _NewProjectDialogState();
}

class _NewProjectDialogState extends State<NewProjectDialog> {
  static final RegExp _valid = RegExp(r'^[A-Za-z0-9._-]{1,100}$');

  final TextEditingController _ctrl = TextEditingController();
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  String get _clean => _ctrl.text.trim().replaceAll(RegExp(r'\s+'), '-');

  Future<void> _create() async {
    final name = _clean;
    if (!_valid.hasMatch(name) || name == '.' || name == '..') {
      setState(() => _error =
          'اسم غير صالح. استخدم أحرفاً إنجليزية وأرقاماً وعلامات - و _ و . فقط.');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final repo = await widget.api.createRepo(name);
      final project = Project(
        name: repo['name'] as String,
        owner: widget.owner,
        branch: (repo['default_branch'] as String?) ?? 'main',
      );
      await widget.store.upsert(project);
      if (mounted) Navigator.of(context).pop(project);
    } on GithubException catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = e.message;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _error = 'حدث خطأ غير متوقع: $e';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AlertDialog(
      title: const Text('مشروع جديد'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('اسم المستودع الذي سيُنشأ على GitHub:'),
          const SizedBox(height: 12),
          TextField(
            controller: _ctrl,
            enabled: !_busy,
            autofocus: true,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(
              hintText: 'my-app',
              border: OutlineInputBorder(),
            ),
            onChanged: (_) => setState(() => _error = null),
            onSubmitted: (_) => _busy ? null : _create(),
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Text(_error!, style: TextStyle(color: theme.colorScheme.error)),
          ],
          if (_busy) ...[
            const SizedBox(height: 16),
            const LinearProgressIndicator(),
            const SizedBox(height: 8),
            const Text('جارٍ إنشاء المستودع...'),
          ],
        ],
      ),
      actions: [
        TextButton(
          onPressed: _busy ? null : () => Navigator.of(context).pop(),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: _busy ? null : _create,
          child: const Text('إنشاء'),
        ),
      ],
    );
  }
}

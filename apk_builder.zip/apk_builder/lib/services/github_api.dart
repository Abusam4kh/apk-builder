import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:http/http.dart' as http;

class GithubException implements Exception {
  GithubException(this.message, {this.status});

  final String message;

  /// رمز HTTP إن كان الخطأ جاء من GitHub، وnull إن كان خطأ اتصال.
  final int? status;

  @override
  String toString() => message;
}

class GithubApi {
  GithubApi(this.token);

  final String token;

  static const String _base = 'https://api.github.com';

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $token',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'apk-builder-app',
      };

  // ---------------------------------------------------------------- helpers

  Future<http.Response> _send(
    String method,
    String path, {
    Object? body,
    Duration timeout = const Duration(seconds: 60),
  }) async {
    final req = http.Request(method, Uri.parse('$_base$path'));
    req.headers.addAll(_headers);
    if (body != null) {
      req.headers['Content-Type'] = 'application/json; charset=utf-8';
      req.body = jsonEncode(body);
    }
    try {
      final streamed = await req.send().timeout(timeout);
      return await http.Response.fromStream(streamed).timeout(timeout);
    } on TimeoutException {
      throw GithubException('انتهت مهلة الاتصال بـ GitHub');
    } on SocketException {
      throw GithubException('تعذّر الاتصال بالإنترنت');
    } on http.ClientException {
      throw GithubException('تعذّر الاتصال بالإنترنت');
    }
  }

  void _check(http.Response res) {
    if (res.statusCode >= 200 && res.statusCode < 300) return;
    var msg = '';
    try {
      final j = jsonDecode(res.body);
      if (j is Map && j['message'] != null) msg = j['message'].toString();
    } catch (_) {}
    throw GithubException(
      _explain(res.statusCode, msg, res.body),
      status: res.statusCode,
    );
  }

  String _explain(int code, String msg, String body) {
    final lower = body.toLowerCase();
    if (code == 401) return 'انتهت صلاحية تسجيل الدخول، سجّل الدخول من جديد.';
    if (code == 403 && lower.contains('rate limit')) {
      return 'تجاوزت حدّ الطلبات المسموح من GitHub، حاول بعد قليل.';
    }
    if (code == 422 && lower.contains('already exists')) {
      return 'يوجد مستودع بهذا الاسم في حسابك، اختر اسماً آخر.';
    }
    if (code == 403) return 'ليست لديك صلاحية لهذه العملية ($msg).';
    return 'خطأ من GitHub ($code): $msg';
  }

  // ------------------------------------------------------------------- user

  Future<String> currentLogin() async {
    final res = await _send('GET', '/user');
    _check(res);
    return (jsonDecode(res.body) as Map<String, dynamic>)['login'] as String;
  }

  // ------------------------------------------------------------------ repos

  Future<Map<String, dynamic>> createRepo(String name) async {
    final res = await _send('POST', '/user/repos', body: {
      'name': name,
      'description': 'Created by APK Builder',
      'private': true,
      'auto_init': true,
    });
    _check(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// يعيد sha الملف إن كان موجوداً في المستودع (مطلوب لتحديث ملف موجود)،
  /// ويقرأه من قائمة المجلد حتى لا نصطدم بحدّ 1MB لقراءة الملف نفسه.
  Future<String?> fileSha(
    String owner,
    String repo,
    String path,
    String branch,
  ) async {
    final idx = path.lastIndexOf('/');
    final dir = idx < 0 ? '' : path.substring(0, idx);
    final name = idx < 0 ? path : path.substring(idx + 1);
    final res = await _send(
      'GET',
      '/repos/$owner/$repo/contents/$dir?ref=${Uri.encodeQueryComponent(branch)}',
    );
    if (res.statusCode == 404) return null;
    _check(res);
    final j = jsonDecode(res.body);
    if (j is List) {
      for (final e in j) {
        if (e is Map && e['name'] == name) return e['sha'] as String?;
      }
    }
    return null;
  }

  Future<void> putTextFile(
    String owner,
    String repo,
    String path,
    String content, {
    required String branch,
    required String message,
    String? sha,
  }) async {
    final res = await _send('PUT', '/repos/$owner/$repo/contents/$path', body: {
      'message': message,
      'branch': branch,
      'content': base64.encode(utf8.encode(content)),
      if (sha != null) 'sha': sha,
    });
    _check(res);
  }

  /// رفع ملف كبير بالبثّ (بدون تحميله كله في الذاكرة) مع نسبة تقدّم.
  Future<void> putLargeFile(
    String owner,
    String repo,
    String path,
    File file, {
    required String branch,
    required String message,
    String? sha,
    void Function(double fraction)? onProgress,
  }) async {
    final length = await file.length();
    final req = http.StreamedRequest(
      'PUT',
      Uri.parse('$_base/repos/$owner/$repo/contents/$path'),
    );
    req.headers.addAll(_headers);
    req.headers['Content-Type'] = 'application/json; charset=utf-8';

    final headStr = StringBuffer('{"message":')
      ..write(jsonEncode(message))
      ..write(',"branch":')
      ..write(jsonEncode(branch));
    if (sha != null) {
      headStr
        ..write(',"sha":')
        ..write(jsonEncode(sha));
    }
    headStr.write(',"content":"');
    final head = utf8.encode(headStr.toString());
    final tail = utf8.encode('"}');
    final b64Len = ((length + 2) ~/ 3) * 4;
    req.contentLength = head.length + b64Len + tail.length;

    final sendFuture = req.send();

    Future<void> pump() async {
      final raf = await file.open();
      try {
        req.sink.add(head);
        // مضاعف للعدد 3 حتى لا تظهر علامات الحشو (=) في منتصف المحتوى.
        const chunk = 3 * 48 * 1024;
        var sent = 0;
        while (sent < length) {
          final data = await _readFull(raf, math.min(chunk, length - sent));
          if (data.isEmpty) break;
          req.sink.add(ascii.encode(base64.encode(data)));
          sent += data.length;
          onProgress?.call(sent / length);
          await Future<void>.delayed(Duration.zero);
        }
        req.sink.add(tail);
      } catch (e, st) {
        // نُمرّر الخطأ إلى الطلب نفسه حتى لا يبقى معلّقاً.
        req.sink.addError(e, st);
      } finally {
        await raf.close();
        await req.sink.close();
      }
    }

    final pumpFuture = pump();
    try {
      final streamed = await sendFuture.timeout(const Duration(minutes: 20));
      final res = await http.Response.fromStream(streamed);
      await pumpFuture;
      _check(res);
    } on TimeoutException {
      throw GithubException('انتهت مهلة رفع الملف');
    } on SocketException {
      throw GithubException('انقطع الاتصال أثناء رفع الملف');
    } on http.ClientException {
      throw GithubException('انقطع الاتصال أثناء رفع الملف');
    }
  }

  static Future<Uint8List> _readFull(RandomAccessFile raf, int n) async {
    final b = BytesBuilder(copy: false);
    var left = n;
    while (left > 0) {
      final d = await raf.read(left);
      if (d.isEmpty) break;
      b.add(d);
      left -= d.length;
    }
    return b.takeBytes();
  }

  // ---------------------------------------------------------------- actions

  Future<void> dispatch(
    String owner,
    String repo,
    String workflowFile,
    String ref,
  ) async {
    final res = await _send(
      'POST',
      '/repos/$owner/$repo/actions/workflows/$workflowFile/dispatches',
      body: {'ref': ref},
    );
    _check(res);
  }

  Future<List<Map<String, dynamic>>> listRuns(
    String owner,
    String repo, {
    int perPage = 10,
  }) async {
    final res = await _send(
      'GET',
      '/repos/$owner/$repo/actions/runs?per_page=$perPage',
    );
    _check(res);
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    return ((j['workflow_runs'] as List?) ?? const [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
  }

  Future<Map<String, dynamic>> getRun(String owner, String repo, int id) async {
    final res = await _send('GET', '/repos/$owner/$repo/actions/runs/$id');
    _check(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  Future<List<Map<String, dynamic>>> listJobs(
    String owner,
    String repo,
    int runId,
  ) async {
    final res = await _send(
      'GET',
      '/repos/$owner/$repo/actions/runs/$runId/jobs?per_page=30',
    );
    _check(res);
    final j = jsonDecode(res.body) as Map<String, dynamic>;
    return ((j['jobs'] as List?) ?? const [])
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList();
  }

  Future<void> cancelRun(String owner, String repo, int runId) async {
    final res = await _send('POST', '/repos/$owner/$repo/actions/runs/$runId/cancel');
    _check(res);
  }

  /// سجل الـ job كنص. GitHub يعيد توجيهاً (302) إلى رابط موقّع، ولا يجب
  /// إرسال ترويسة Authorization إلى ذلك الرابط، لذلك نتبع التوجيه يدوياً.
  Future<String> jobLogs(String owner, String repo, int jobId) async {
    final client = http.Client();
    try {
      final req = http.Request(
        'GET',
        Uri.parse('$_base/repos/$owner/$repo/actions/jobs/$jobId/logs'),
      )
        ..followRedirects = false
        ..headers.addAll(_headers);
      var res = await client.send(req).timeout(const Duration(seconds: 60));
      if (res.statusCode >= 300 && res.statusCode < 400) {
        final loc = res.headers['location'];
        await res.stream.drain<void>();
        if (loc == null) throw GithubException('تعذّر جلب سجل التجميع');
        res = await client
            .send(http.Request('GET', Uri.parse(loc)))
            .timeout(const Duration(seconds: 60));
      }
      final body = await res.stream.bytesToString();
      if (res.statusCode != 200) {
        throw GithubException('تعذّر جلب سجل التجميع (${res.statusCode})',
            status: res.statusCode);
      }
      return body;
    } on TimeoutException {
      throw GithubException('انتهت مهلة جلب السجل');
    } on SocketException {
      throw GithubException('تعذّر الاتصال بالإنترنت');
    } on http.ClientException {
      throw GithubException('تعذّر الاتصال بالإنترنت');
    } finally {
      client.close();
    }
  }

  // --------------------------------------------------------------- releases

  Future<Map<String, dynamic>> releaseByTag(
    String owner,
    String repo,
    String tag,
  ) async {
    final res = await _send('GET', '/repos/$owner/$repo/releases/tags/$tag');
    _check(res);
    return jsonDecode(res.body) as Map<String, dynamic>;
  }

  /// تنزيل ملف من الإصدار. المستودع خاص، فالتنزيل يمرّ عبر الـ API ثم يُعاد
  /// توجيهه إلى رابط موقّع نطلبه بدون Authorization.
  Future<void> downloadAsset(
    String owner,
    String repo,
    int assetId,
    File dest, {
    void Function(double? fraction)? onProgress,
  }) async {
    final client = http.Client();
    try {
      final req = http.Request(
        'GET',
        Uri.parse('$_base/repos/$owner/$repo/releases/assets/$assetId'),
      )
        ..followRedirects = false
        ..headers.addAll({..._headers, 'Accept': 'application/octet-stream'});
      var res = await client.send(req).timeout(const Duration(seconds: 60));
      if (res.statusCode >= 300 && res.statusCode < 400) {
        final loc = res.headers['location'];
        await res.stream.drain<void>();
        if (loc == null) throw GithubException('تعذّر تنزيل الملف');
        res = await client
            .send(http.Request('GET', Uri.parse(loc)))
            .timeout(const Duration(seconds: 60));
      }
      if (res.statusCode != 200) {
        throw GithubException('تعذّر تنزيل الملف (${res.statusCode})',
            status: res.statusCode);
      }
      final total = res.contentLength ?? 0;
      await dest.parent.create(recursive: true);
      final sink = dest.openWrite();
      var got = 0;
      try {
        await for (final chunk in res.stream) {
          sink.add(chunk);
          got += chunk.length;
          onProgress?.call(total > 0 ? got / total : null);
        }
      } finally {
        await sink.close();
      }
    } on TimeoutException {
      throw GithubException('انتهت مهلة تنزيل الملف');
    } on SocketException {
      throw GithubException('انقطع الاتصال أثناء تنزيل الملف');
    } on http.ClientException {
      throw GithubException('انقطع الاتصال أثناء تنزيل الملف');
    } finally {
      client.close();
    }
  }
}

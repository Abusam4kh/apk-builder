import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';
import 'github_api.dart';

class DeviceCode {
  DeviceCode({
    required this.deviceCode,
    required this.userCode,
    required this.verificationUri,
    required this.interval,
    required this.expiresIn,
  });

  final String deviceCode;
  final String userCode;
  final String verificationUri;
  final int interval;
  final int expiresIn;
}

class Session {
  Session(this.token, this.login) : api = GithubApi(token);

  final String token;
  final String login;
  final GithubApi api;
}

/// تسجيل الدخول عبر GitHub Device Flow: يظهر كود تحقق يُدخله المستخدم في
/// github.com/login/device مرة واحدة، ثم يُحفظ التوكن بشكل مشفّر.
class AuthService {
  static const FlutterSecureStorage _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const String _tokenKey = 'gh_token';
  static const String _loginKey = 'gh_login';
  static const String _clientKey = 'client_id';

  // ------------------------------------------------------------- client id

  Future<String?> resolveClientId() async {
    if (AppConfig.definedClientId.isNotEmpty) return AppConfig.definedClientId;
    final prefs = await SharedPreferences.getInstance();
    final v = prefs.getString(_clientKey);
    return (v == null || v.isEmpty) ? null : v;
  }

  Future<void> saveClientId(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_clientKey, id);
  }

  // --------------------------------------------------------------- session

  Future<Session?> loadSession() async {
    try {
      final token = await _storage.read(key: _tokenKey);
      final login = await _storage.read(key: _loginKey);
      if (token == null || login == null) return null;
      return Session(token, login);
    } catch (_) {
      return null;
    }
  }

  Future<void> saveSession(String token, String login) async {
    await _storage.write(key: _tokenKey, value: token);
    await _storage.write(key: _loginKey, value: login);
  }

  Future<void> clear() async {
    try {
      await _storage.delete(key: _tokenKey);
      await _storage.delete(key: _loginKey);
    } catch (_) {}
  }

  // ----------------------------------------------------------- device flow

  Future<DeviceCode> startDeviceFlow(String clientId) async {
    final j = await _post('https://github.com/login/device/code', {
      'client_id': clientId,
      'scope': AppConfig.scope,
    });
    if (j['error'] != null) throw GithubException(_explain(j['error'].toString()));
    return DeviceCode(
      deviceCode: j['device_code'] as String,
      userCode: j['user_code'] as String,
      verificationUri:
          (j['verification_uri'] as String?) ?? 'https://github.com/login/device',
      interval: (j['interval'] as num?)?.toInt() ?? 5,
      expiresIn: (j['expires_in'] as num?)?.toInt() ?? 900,
    );
  }

  /// ينتظر حتى يؤكّد المستخدم الكود في GitHub ثم يعيد التوكن.
  Future<String> pollForToken(
    String clientId,
    DeviceCode code, {
    required bool Function() cancelled,
  }) async {
    var interval = code.interval;
    final deadline = DateTime.now().add(Duration(seconds: code.expiresIn));
    while (DateTime.now().isBefore(deadline)) {
      await Future<void>.delayed(Duration(seconds: interval));
      if (cancelled()) throw GithubException('تم إلغاء تسجيل الدخول');
      Map<String, dynamic>? j;
      try {
        j = await _post('https://github.com/login/oauth/access_token', {
          'client_id': clientId,
          'device_code': code.deviceCode,
          'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
        });
      } on GithubException {
        j = null; // انقطاع مؤقت في الاتصال، نعيد المحاولة
      }
      if (j == null) continue;
      final token = j['access_token'];
      if (token is String && token.isNotEmpty) return token;
      final error = j['error']?.toString();
      if (error == 'authorization_pending') continue;
      if (error == 'slow_down') {
        interval = ((j['interval'] as num?)?.toInt() ?? interval + 5);
        continue;
      }
      throw GithubException(_explain(error ?? 'unknown'));
    }
    throw GithubException('انتهت مهلة الكود. ابدأ من جديد.');
  }

  Future<Map<String, dynamic>> _post(String url, Map<String, String> body) async {
    try {
      final res = await http
          .post(Uri.parse(url), headers: {'Accept': 'application/json'}, body: body)
          .timeout(const Duration(seconds: 30));
      final decoded = jsonDecode(res.body);
      if (decoded is Map<String, dynamic>) return decoded;
      throw GithubException('رد غير متوقع من GitHub');
    } on TimeoutException {
      throw GithubException('انتهت مهلة الاتصال بـ GitHub');
    } on SocketException {
      throw GithubException('تعذّر الاتصال بالإنترنت');
    } on http.ClientException {
      throw GithubException('تعذّر الاتصال بالإنترنت');
    } on FormatException {
      throw GithubException('رد غير متوقع من GitHub');
    }
  }

  String _explain(String code) {
    switch (code) {
      case 'device_flow_disabled':
        return 'خاصية Device Flow غير مفعّلة. افتح إعدادات OAuth App على GitHub وفعّل Enable Device Flow.';
      case 'incorrect_client_credentials':
        return 'Client ID غير صحيح.';
      case 'expired_token':
        return 'انتهت صلاحية الكود. ابدأ من جديد.';
      case 'access_denied':
        return 'تم رفض الطلب من GitHub.';
      default:
        return 'تعذّر تسجيل الدخول ($code)';
    }
  }
}

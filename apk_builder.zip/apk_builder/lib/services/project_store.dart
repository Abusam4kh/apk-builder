import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models.dart';

/// قائمة المشاريع محفوظة محلياً على الجهاز.
class ProjectStore {
  static const String _key = 'projects_v1';

  Future<List<Project>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    try {
      final list = jsonDecode(raw) as List;
      return list
          .map((e) => Project.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> _saveAll(List<Project> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  Future<void> upsert(Project project) async {
    final items = await load();
    final i = items.indexWhere((e) => e.fullName == project.fullName);
    if (i >= 0) {
      items[i] = project;
    } else {
      items.insert(0, project);
    }
    await _saveAll(items);
  }

  Future<void> remove(Project project) async {
    final items = await load();
    items.removeWhere((e) => e.fullName == project.fullName);
    await _saveAll(items);
  }
}

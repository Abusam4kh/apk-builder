import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../config.dart';
import '../models.dart';
import 'github_api.dart';
import 'project_store.dart';
import 'workflow_template.dart';

class _Cancelled implements Exception {}

class _Snapshot {
  _Snapshot(this.run, this.jobs);
  final Map<String, dynamic> run;
  final List<Map<String, dynamic>> jobs;
}

/// يدير رحلة التجميع كاملة:
/// رفع ZIP -> إنشاء الـ workflow -> تشغيله -> متابعة الخطوات -> تنزيل APK أو جلب الخطأ.
class BuildController extends ChangeNotifier {
  BuildController({
    required this.api,
    required this.project,
    required this.store,
  });

  final GithubApi api;
  final Project project;
  final ProjectStore store;

  final List<String> logs = <String>[];
  bool busy = false;
  bool started = false;
  bool finished = false;
  bool succeeded = false;
  double? progress = 0;
  String stage = '';
  String? errorSummary;
  String? errorLog;
  File? apkFile;
  int? apkBytes;

  bool _cancelled = false;
  bool _disposed = false;
  int? _activeRunId;

  String get _owner => project.owner;
  String get _repo => project.name;

  @override
  void dispose() {
    _disposed = true;
    _cancelled = true;
    super.dispose();
  }

  // ---------------------------------------------------------------- state

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  void _log(String message) {
    final n = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    logs.add('[${two(n.hour)}:${two(n.minute)}:${two(n.second)}] $message');
    _notify();
  }

  void _setStage(String title, double? value) {
    stage = title;
    progress = value;
    _log(title);
  }

  void _setProgress(double value) {
    progress = value.clamp(0.0, 1.0).toDouble();
    _notify();
  }

  void _reset() {
    logs.clear();
    started = true;
    finished = false;
    succeeded = false;
    progress = 0;
    stage = '';
    errorSummary = null;
    errorLog = null;
    apkFile = null;
    apkBytes = null;
    _cancelled = false;
    _activeRunId = null;
  }

  void _fail(String message) {
    errorSummary = message;
    finished = true;
    succeeded = false;
    _log('✗ $message');
  }

  Future<void> _run(Future<void> Function() body) async {
    busy = true;
    _notify();
    try {
      await body();
    } on _Cancelled {
      errorSummary = 'تم إيقاف المتابعة';
      finished = true;
      _log('تم إيقاف المتابعة');
    } on GithubException catch (e) {
      _fail(e.message);
    } catch (e) {
      _fail('خطأ غير متوقع: $e');
    } finally {
      busy = false;
      if (succeeded) progress = 1;
      _notify();
    }
  }

  // ---------------------------------------------------------- entry points

  /// يرفع ملف ZIP ويشغّل التجميع ويتابعه حتى النهاية.
  Future<void> start(File zip) async {
    if (busy) return;
    _reset();
    await _run(() async {
      await _upload(zip);
      final runId = await _dispatchAndFindRun();
      await _monitor(runId);
    });
  }

  /// يعرض نتيجة آخر عملية تجميع محفوظة لهذا المشروع.
  Future<void> showLast() async {
    final id = project.runId;
    if (busy || id == null) return;
    _reset();
    await _run(() async {
      _log('جلب حالة آخر عملية تجميع...');
      await _monitor(id);
    });
  }

  Future<void> cancel() async {
    _cancelled = true;
    final id = _activeRunId;
    if (id != null) {
      try {
        await api.cancelRun(_owner, _repo, id);
        _log('أُرسل طلب إلغاء التجميع إلى GitHub');
      } catch (_) {}
    }
  }

  // --------------------------------------------------------------- upload

  Future<void> _upload(File zip) async {
    final size = await zip.length();
    if (size == 0) throw GithubException('الملف فارغ');
    if (size > AppConfig.maxZipBytes) {
      throw GithubException(
        'حجم الملف ${formatSize(size)} يتجاوز الحد المسموح (${formatSize(AppConfig.maxZipBytes)}).',
      );
    }
    await _checkZipHeader(zip);

    _setStage('رفع ملف المشروع (${formatSize(size)})', 0);
    final zipSha =
        await api.fileSha(_owner, _repo, AppConfig.zipPath, project.branch);
    await _retry(() => api.putLargeFile(
          _owner,
          _repo,
          AppConfig.zipPath,
          zip,
          branch: project.branch,
          message: 'Add project.zip',
          sha: zipSha,
          onProgress: (f) => _setProgress(f * 0.25),
        ));
    _log('✓ تم رفع الملف');

    _setStage('إنشاء ملف التجميع (workflow)', 0.27);
    final wfSha =
        await api.fileSha(_owner, _repo, AppConfig.workflowPath, project.branch);
    await _retry(() => api.putTextFile(
          _owner,
          _repo,
          AppConfig.workflowPath,
          workflowYaml,
          branch: project.branch,
          message: 'Add build workflow',
          sha: wfSha,
        ));
    _log('✓ تم إنشاء الـ workflow');
  }

  Future<void> _checkZipHeader(File f) async {
    final raf = await f.open();
    try {
      final head = await raf.read(4);
      final ok = head.length == 4 &&
          head[0] == 0x50 &&
          head[1] == 0x4B &&
          (head[2] == 3 || head[2] == 5);
      if (!ok) throw GithubException('الملف المختار ليس ملف ZIP صالحاً');
    } finally {
      await raf.close();
    }
  }

  Future<T> _retry<T>(Future<T> Function() action, {int attempts = 4}) async {
    for (var i = 1;; i++) {
      try {
        return await action();
      } on GithubException catch (e) {
        final retryable = e.status == null ||
            e.status == 404 ||
            e.status == 409 ||
            e.status == 500 ||
            e.status == 502 ||
            e.status == 503;
        if (i >= attempts || !retryable || _cancelled) rethrow;
        _log('إعادة المحاولة ($i/$attempts)...');
        await Future<void>.delayed(Duration(seconds: 3 * i));
      }
    }
  }

  // ------------------------------------------------------------- dispatch

  Future<int> _dispatchAndFindRun() async {
    final before = await api.listRuns(_owner, _repo);
    final beforeId =
        before.fold<int>(0, (m, r) => math.max(m, (r['id'] as num).toInt()));

    _setStage('بدء التجميع على GitHub', 0.3);
    var dispatched = false;
    for (var i = 1; i <= 12 && !dispatched; i++) {
      if (_cancelled) throw _Cancelled();
      try {
        await api.dispatch(_owner, _repo, AppConfig.workflowFile, project.branch);
        dispatched = true;
      } on GithubException catch (e) {
        // الـ workflow المنشأ حديثاً قد يحتاج بضع ثوانٍ ليُعرَف.
        if ((e.status == 404 || e.status == 422) && i < 12) {
          await Future<void>.delayed(const Duration(seconds: 4));
        } else {
          rethrow;
        }
      }
    }
    _log('✓ تم طلب التجميع');

    for (var i = 0; i < 40; i++) {
      await Future<void>.delayed(const Duration(seconds: 3));
      if (_cancelled) throw _Cancelled();
      final runs = await api.listRuns(_owner, _repo);
      final fresh =
          runs.where((r) => (r['id'] as num).toInt() > beforeId).toList();
      if (fresh.isNotEmpty) {
        final run = fresh.first;
        final id = (run['id'] as num).toInt();
        project.status = 'building';
        project.runId = id;
        await store.upsert(project);
        _log('بدأ التجميع (#${run['run_number']})');
        return id;
      }
    }
    throw GithubException(
      'لم يبدأ التجميع على GitHub. تأكد أن GitHub Actions مفعّلة للمستودع.',
    );
  }

  // -------------------------------------------------------------- monitor

  Future<_Snapshot> _snapshot(int runId) async {
    final run = await api.getRun(_owner, _repo, runId);
    final jobs = await api.listJobs(_owner, _repo, runId);
    return _Snapshot(run, jobs);
  }

  Future<void> _monitor(int runId) async {
    _activeRunId = runId;
    _setStage('التجميع على GitHub', 0.35);
    final seen = <String, String>{};
    final startedAt = DateTime.now();
    var failures = 0;
    var lastRunStatus = '';

    while (true) {
      if (_cancelled) throw _Cancelled();
      if (DateTime.now().difference(startedAt) > const Duration(minutes: 75)) {
        throw GithubException('استغرق التجميع أكثر من المدة المسموحة');
      }

      _Snapshot? snap;
      try {
        snap = await _snapshot(runId);
        failures = 0;
      } on GithubException catch (e) {
        // انقطاع اتصال عابر: نحاول من جديد، وغير ذلك نُظهر الخطأ.
        if (e.status == null && ++failures < 6) {
          snap = null;
        } else {
          rethrow;
        }
      }
      if (snap == null) {
        await Future<void>.delayed(const Duration(seconds: 6));
        continue;
      }
      final current = snap;
      final run = current.run;

      var total = 0;
      var done = 0;
      for (final job in current.jobs) {
        final steps = (job['steps'] as List?) ?? const [];
        for (final raw in steps) {
          final s = Map<String, dynamic>.from(raw as Map);
          total++;
          final status = (s['status'] as String?) ?? '';
          final conclusion = (s['conclusion'] as String?) ?? '';
          if (status == 'completed') done++;
          final state = status == 'completed' ? 'done:$conclusion' : status;
          final key = '${job['id']}-${s['number']}';
          if (seen[key] == state) continue;
          seen[key] = state;
          final name = s['name'];
          if (status == 'in_progress') {
            _log('▶ $name');
          } else if (status == 'completed') {
            if (conclusion == 'success') {
              _log('✓ $name');
            } else if (conclusion == 'failure') {
              _log('✗ $name');
            } else if (conclusion != 'skipped') {
              _log('• $name ($conclusion)');
            }
          }
        }
      }
      if (total > 0) _setProgress(0.35 + 0.55 * done / total);

      final runStatus = (run['status'] as String?) ?? '';
      if (runStatus != lastRunStatus) {
        lastRunStatus = runStatus;
        if (runStatus == 'queued') {
          stage = 'بانتظار تخصيص جهاز التجميع';
          _notify();
        } else if (runStatus == 'in_progress') {
          stage = 'التجميع على GitHub';
          _notify();
        }
      }

      if (runStatus == 'completed') {
        await _finalize(run, current.jobs);
        return;
      }
      await Future<void>.delayed(const Duration(seconds: 6));
    }
  }

  // ------------------------------------------------------------- finalize

  Future<void> _finalize(
    Map<String, dynamic> run,
    List<Map<String, dynamic>> jobs,
  ) async {
    final conclusion = (run['conclusion'] as String?) ?? '';

    if (conclusion == 'success') {
      _setStage('تنزيل ملف APK', 0.9);
      final release = await _fetchRelease('build-${run['run_number']}');
      final assets = ((release['assets'] as List?) ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
      final apks = assets
          .where((a) => (a['name'] as String).toLowerCase().endsWith('.apk'))
          .toList();
      if (apks.isEmpty) {
        throw GithubException(
          'انتهى التجميع بنجاح لكن لم يُعثر على ملف APK في النتيجة.',
        );
      }
      final asset = apks.first;
      final dir = await _apkDir();
      final file = File(p.join(dir.path, asset['name'] as String));
      await api.downloadAsset(
        _owner,
        _repo,
        (asset['id'] as num).toInt(),
        file,
        onProgress: (f) {
          if (f != null) _setProgress(0.9 + 0.1 * f);
        },
      );
      apkFile = file;
      apkBytes = await file.length();
      succeeded = true;
      finished = true;
      progress = 1;
      project.status = 'success';
      await store.upsert(project);
      _log('✓ تم تنزيل الملف (${formatSize(apkBytes!)})');
      _log(file.path);
      return;
    }

    project.status = 'failure';
    await store.upsert(project);
    finished = true;
    if (conclusion == 'cancelled') {
      errorSummary = 'تم إلغاء التجميع';
      _log('✗ تم إلغاء التجميع');
    } else {
      errorSummary = 'فشل التجميع';
      _log('✗ فشل التجميع');
      await _collectError(jobs);
    }
  }

  Future<Map<String, dynamic>> _fetchRelease(String tag) async {
    for (var i = 0; i < 6; i++) {
      try {
        return await api.releaseByTag(_owner, _repo, tag);
      } on GithubException catch (e) {
        if (e.status != 404 || i == 5) rethrow;
        await Future<void>.delayed(const Duration(seconds: 3));
      }
    }
    throw GithubException('لم يتم العثور على نتيجة التجميع');
  }

  Future<Directory> _apkDir() async {
    Directory? base;
    try {
      base = await getExternalStorageDirectory();
    } catch (_) {}
    base ??= await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'apks'));
    await dir.create(recursive: true);
    return dir;
  }

  // ---------------------------------------------------------------- error

  Future<void> _collectError(List<Map<String, dynamic>> jobs) async {
    final failed = jobs.where((j) => j['conclusion'] == 'failure').toList();
    if (failed.isEmpty) return;
    final job = failed.first;
    for (final raw in (job['steps'] as List?) ?? const []) {
      final s = Map<String, dynamic>.from(raw as Map);
      if (s['conclusion'] == 'failure') {
        errorSummary = 'فشلت الخطوة: ${s['name']}';
        break;
      }
    }
    try {
      final raw = await api.jobLogs(_owner, _repo, (job['id'] as num).toInt());
      errorLog = _tail(raw);
    } catch (e) {
      errorLog = 'تعذّر جلب سجل الخطأ: $e';
    }
    _notify();
  }

  String _tail(String raw) {
    final ts = RegExp(r'^\d{4}-\d{2}-\d{2}T[\d:.]+Z\s?');
    final ansi = RegExp(r'\x1B\[[0-9;]*m');
    final lines = raw
        .split('\n')
        .map((l) => l.replaceFirst(ts, '').replaceAll(ansi, '').trimRight())
        .where((l) => l.isNotEmpty)
        .toList();
    final errors = lines
        .where((l) => l.startsWith('##[error]'))
        .map((l) => l.substring(9))
        .toList();
    final plain = lines.where((l) => !l.startsWith('##[')).toList();
    final last = plain.length > 50 ? plain.sublist(plain.length - 50) : plain;
    final b = StringBuffer();
    if (errors.isNotEmpty) {
      b.writeln('--- الأخطاء ---');
      for (final e in errors.take(15)) {
        b.writeln(e);
      }
      b.writeln();
    }
    b.writeln('--- آخر سطور السجل ---');
    b.writeAll(last, '\n');
    return b.toString();
  }
}

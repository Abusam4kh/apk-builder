// ملف مُولَّد من bootstrap/build-apk.yml — لا تعدّله يدوياً.
// الـ workflow الذي يرفعه التطبيق إلى كل مستودع جديد.
const String workflowYaml = r'''name: Build APK

on:
  workflow_dispatch:

permissions:
  contents: write

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 60
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Unzip project
        run: |
          set -e
          if [ ! -f project.zip ]; then
            echo "::error::project.zip was not found in the repository"
            exit 1
          fi
          DIR="$RUNNER_TEMP/proj"
          mkdir -p "$DIR"
          unzip -q -o project.zip -d "$DIR" || test $? -le 1
          rm -rf "$DIR/__MACOSX"
          cd "$DIR"
          # If the ZIP contains a single top-level folder, step into it
          while [ ! -f pubspec.yaml ] && [ ! -f settings.gradle ] && [ ! -f settings.gradle.kts ] && [ ! -f build.gradle ] && [ ! -f build.gradle.kts ]; do
            if [ "$(ls -A | wc -l)" = "1" ] && [ -d "$(ls -A)" ]; then
              cd "$(ls -A)"
            else
              break
            fi
          done
          if [ -f pubspec.yaml ]; then
            TYPE=flutter
          elif [ -f settings.gradle ] || [ -f settings.gradle.kts ] || [ -f build.gradle ] || [ -f build.gradle.kts ]; then
            TYPE=android
          else
            echo "::error::Unsupported project. No pubspec.yaml or Gradle build files were found at the root of the ZIP."
            exit 1
          fi
          echo "Detected project type: $TYPE"
          echo "PROJECT_DIR=$(pwd)" >> "$GITHUB_ENV"
          echo "PROJECT_TYPE=$TYPE" >> "$GITHUB_ENV"

      - name: Set up Java
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Flutter
        if: env.PROJECT_TYPE == 'flutter'
        uses: subosito/flutter-action@v2
        with:
          channel: stable
          cache: true

      - name: Build Flutter APK
        if: env.PROJECT_TYPE == 'flutter'
        run: |
          set -e
          cd "$PROJECT_DIR"
          if [ ! -d android ]; then
            NAME=$(grep -m1 '^name:' pubspec.yaml | sed -E 's/^name:[[:space:]]*//' | tr -d "\"' \r")
            flutter create --platforms=android --project-name "$NAME" --org com.example .
            if [ -f tool/patch_android.py ]; then
              python3 tool/patch_android.py
            fi
          fi
          flutter pub get
          flutter build apk --release

      - name: Build Android (Gradle) APK
        if: env.PROJECT_TYPE == 'android'
        run: |
          set -e
          cd "$PROJECT_DIR"
          if [ -f gradlew ]; then
            chmod +x gradlew
            ./gradlew assembleDebug --no-daemon
          else
            gradle assembleDebug --no-daemon
          fi

      - name: Collect APK
        run: |
          set -e
          APK=$(find "$PROJECT_DIR" -name '*.apk' -path '*/build/*' -not -path '*/intermediates/*' | head -n1)
          if [ -z "$APK" ]; then
            echo "::error::The build finished but no APK file was found"
            exit 1
          fi
          mkdir -p out
          cp "$APK" "out/${GITHUB_REPOSITORY#*/}-build${GITHUB_RUN_NUMBER}.apk"
          ls -lh out

      - name: Upload artifact
        uses: actions/upload-artifact@v4
        with:
          name: apk
          path: out/*.apk

      - name: Publish release
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          gh release create "build-${{ github.run_number }}" out/*.apk \
            --repo "$GITHUB_REPOSITORY" \
            --target "$GITHUB_SHA" \
            --title "Build #${{ github.run_number }}" \
            --notes "Built by APK Builder"
''';

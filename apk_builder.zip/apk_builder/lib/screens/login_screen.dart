import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../services/auth_service.dart';
import '../services/github_api.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.auth, required this.onLoggedIn});

  final AuthService auth;
  final void Function(Session session) onLoggedIn;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _clientCtrl = TextEditingController();
  String? _clientId;
  bool _clientLoaded = false;
  DeviceCode? _code;
  String? _error;
  bool _busy = false;
  bool _cancelled = false;

  @override
  void initState() {
    super.initState();
    _loadClient();
  }

  @override
  void dispose() {
    _cancelled = true;
    _clientCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadClient() async {
    final id = await widget.auth.resolveClientId();
    if (!mounted) return;
    setState(() {
      _clientId = id;
      _clientLoaded = true;
    });
  }

  Future<void> _start() async {
    setState(() {
      _busy = true;
      _error = null;
      _cancelled = false;
      _code = null;
    });
    try {
      var cid = _clientId;
      if (cid == null || cid.isEmpty) {
        cid = _clientCtrl.text.trim();
        if (cid.isEmpty) throw GithubException('أدخل Client ID أولاً');
        await widget.auth.saveClientId(cid);
        _clientId = cid;
      }
      final dc = await widget.auth.startDeviceFlow(cid);
      if (!mounted) return;
      setState(() => _code = dc);
      await Clipboard.setData(ClipboardData(text: dc.userCode));
      await _openGithub();
      final token = await widget.auth.pollForToken(
        cid,
        dc,
        cancelled: () => _cancelled || !mounted,
      );
      final login = await GithubApi(token).currentLogin();
      await widget.auth.saveSession(token, login);
      if (!mounted) return;
      widget.onLoggedIn(Session(token, login));
    } on GithubException catch (e) {
      if (mounted && !_cancelled) setState(() => _error = e.message);
    } catch (e) {
      if (mounted && !_cancelled) setState(() => _error = 'حدث خطأ غير متوقع: $e');
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          if (_error != null) _code = null;
        });
      }
    }
  }

  Future<void> _openGithub() async {
    final uri = Uri.parse(_code?.verificationUri ?? 'https://github.com/login/device');
    try {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } catch (_) {}
  }

  void _cancel() {
    _cancelled = true;
    setState(() {
      _busy = false;
      _code = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Icon(Icons.android, size: 72, color: theme.colorScheme.primary),
                  const SizedBox(height: 12),
                  Text(
                    'بنّاء APK',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'جمّع مشاريعك إلى APK عبر GitHub Actions دون فتح GitHub.',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 32),
                  if (!_clientLoaded)
                    const Center(child: CircularProgressIndicator())
                  else if (_code == null)
                    ..._startSection(theme)
                  else
                    ..._codeSection(theme, _code!),
                  if (_error != null) ...[
                    const SizedBox(height: 16),
                    Card(
                      color: theme.colorScheme.errorContainer,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(
                          _error!,
                          style: TextStyle(color: theme.colorScheme.onErrorContainer),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _startSection(ThemeData theme) {
    return [
      if (_clientId == null) ...[
        TextField(
          controller: _clientCtrl,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(
            labelText: 'GitHub Client ID',
            helperText: 'من إعدادات OAuth App على GitHub. يُدخَل مرة واحدة فقط.',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 16),
      ],
      FilledButton.icon(
        onPressed: _busy ? null : _start,
        icon: _busy
            ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : const Icon(Icons.login),
        label: const Text('تسجيل الدخول عبر GitHub'),
      ),
      const SizedBox(height: 12),
      Text(
        'سيظهر كود تحقق تُدخله في صفحة GitHub مرة واحدة فقط.',
        textAlign: TextAlign.center,
        style: theme.textTheme.bodySmall,
      ),
    ];
  }

  List<Widget> _codeSection(ThemeData theme, DeviceCode code) {
    return [
      Text(
        'أدخل هذا الكود في صفحة GitHub',
        textAlign: TextAlign.center,
        style: theme.textTheme.titleMedium,
      ),
      const SizedBox(height: 16),
      Container(
        padding: const EdgeInsets.symmetric(vertical: 20),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceContainerHighest,
          borderRadius: BorderRadius.circular(16),
        ),
        child: SelectableText(
          code.userCode,
          textAlign: TextAlign.center,
          textDirection: TextDirection.ltr,
          style: theme.textTheme.displaySmall?.copyWith(
            fontWeight: FontWeight.bold,
            letterSpacing: 4,
          ),
        ),
      ),
      const SizedBox(height: 12),
      Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () async {
                await Clipboard.setData(ClipboardData(text: code.userCode));
                if (!mounted) return;
                ScaffoldMessenger.of(context)
                    .showSnackBar(const SnackBar(content: Text('تم نسخ الكود')));
              },
              icon: const Icon(Icons.copy),
              label: const Text('نسخ'),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: FilledButton.icon(
              onPressed: _openGithub,
              icon: const Icon(Icons.open_in_new),
              label: const Text('فتح GitHub'),
            ),
          ),
        ],
      ),
      const SizedBox(height: 24),
      const Center(child: CircularProgressIndicator()),
      const SizedBox(height: 12),
      Text(
        'بانتظار التأكيد... سيُكمل التطبيق تلقائياً بعد إدخال الكود والموافقة.',
        textAlign: TextAlign.center,
        style: theme.textTheme.bodySmall,
      ),
      TextButton(onPressed: _cancel, child: const Text('إلغاء')),
    ];
  }
}

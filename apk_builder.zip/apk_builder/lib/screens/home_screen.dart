import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models.dart';
import '../services/auth_service.dart';
import '../services/project_store.dart';
import '../widgets/new_project_dialog.dart';
import 'project_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.session, required this.onLogout});

  final Session session;
  final Future<void> Function() onLogout;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ProjectStore _store = ProjectStore();
  List<Project> _projects = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final all = await _store.load();
    if (!mounted) return;
    setState(() {
      _projects = all.where((p) => p.owner == widget.session.login).toList();
      _loading = false;
    });
  }

  Future<void> _newProject() async {
    final project = await showDialog<Project>(
      context: context,
      barrierDismissible: false,
      builder: (_) => NewProjectDialog(
        api: widget.session.api,
        owner: widget.session.login,
        store: _store,
      ),
    );
    if (project == null || !mounted) return;
    await _open(project);
  }

  Future<void> _open(Project project) async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => ProjectScreen(
          session: widget.session,
          project: project,
          store: _store,
        ),
      ),
    );
    if (mounted) _load();
  }

  Future<void> _confirmLogout() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('تسجيل الخروج'),
        content: const Text('سيُطلب منك كود تحقق جديد عند الدخول مرة أخرى.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('خروج'),
          ),
        ],
      ),
    );
    if (ok == true) await widget.onLogout();
  }

  Future<void> _remove(Project project) async {
    await _store.remove(project);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('مشاريعي'),
        actions: [
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Text(
                widget.session.login,
                textDirection: TextDirection.ltr,
                style: theme.textTheme.labelLarge,
              ),
            ),
          ),
          IconButton(
            tooltip: 'تسجيل الخروج',
            onPressed: _confirmLogout,
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _newProject,
        icon: const Icon(Icons.add),
        label: const Text('مشروع جديد'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _projects.isEmpty
              ? _empty(theme)
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                  itemCount: _projects.length,
                  itemBuilder: (_, i) => _card(theme, _projects[i]),
                ),
    );
  }

  Widget _empty(ThemeData theme) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.folder_open, size: 64, color: theme.colorScheme.outline),
            const SizedBox(height: 12),
            Text('لا توجد مشاريع بعد', style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            Text(
              'اضغط «مشروع جديد»، اكتب الاسم، ثم اختر ملف ZIP ليُجمَّع إلى APK.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(ThemeData theme, Project p) {
    final scheme = theme.colorScheme;
    late final IconData icon;
    late final Color color;
    switch (p.status) {
      case 'success':
        icon = Icons.check_circle;
        color = Colors.green;
        break;
      case 'failure':
        icon = Icons.error;
        color = scheme.error;
        break;
      case 'building':
        icon = Icons.autorenew;
        color = scheme.primary;
        break;
      default:
        icon = Icons.upload_file;
        color = scheme.outline;
    }
    return Card(
      child: ListTile(
        onTap: () => _open(p),
        leading: Icon(icon, color: color, size: 32),
        title: Text(p.name),
        subtitle: Text(statusLabel(p.status)),
        trailing: PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'github') {
              launchUrl(Uri.parse(p.url), mode: LaunchMode.externalApplication);
            } else if (v == 'remove') {
              _remove(p);
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'github', child: Text('فتح المستودع على GitHub')),
            PopupMenuItem(value: 'remove', child: Text('إزالة من القائمة')),
          ],
        ),
      ),
    );
  }
}

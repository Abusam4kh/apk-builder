import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models.dart';
import '../services/auth_service.dart';
import '../services/build_controller.dart';
import '../services/project_store.dart';

class ProjectScreen extends StatefulWidget {
  const ProjectScreen({
    super.key,
    required this.session,
    required this.project,
    required this.store,
  });

  final Session session;
  final Project project;
  final ProjectStore store;

  @override
  State<ProjectScreen> createState() => _ProjectScreenState();
}

class _ProjectScreenState extends State<ProjectScreen> {
  late final BuildController _c;
  final ScrollController _logScroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _c = BuildController(
      api: widget.session.api,
      project: widget.project,
      store: widget.store,
    );
    _c.addListener(_autoScroll);
  }

  @override
  void dispose() {
    _c.removeListener(_autoScroll);
    _c.dispose();
    _logScroll.dispose();
    super.dispose();
  }

  void _autoScroll() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScroll.hasClients) {
        _logScroll.jumpTo(_logScroll.position.maxScrollExtent);
      }
    });
  }

  Future<void> _pickAndBuild() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['zip'],
      withData: false,
    );
    final path = res?.files.single.path;
    if (path == null) return;
    _c.start(File(path));
  }

  Future<void> _install() async {
    final file = _c.apkFile;
    if (file == null) return;
    final r = await OpenFilex.open(
      file.path,
      type: 'application/vnd.android.package-archive',
    );
    if (r.type != ResultType.done && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'تعذّر فتح الملف للتثبيت. اسمح للتطبيق بتثبيت التطبيقات من الإعدادات ثم أعد المحاولة. (${r.message})',
          ),
        ),
      );
    }
  }

  Future<void> _copy(String text, String done) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(done)));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.project.name),
        actions: [
          IconButton(
            tooltip: 'فتح المستودع على GitHub',
            icon: const Icon(Icons.open_in_new),
            onPressed: () => launchUrl(
              Uri.parse(widget.project.url),
              mode: LaunchMode.externalApplication,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListenableBuilder(
          listenable: _c,
          builder: (context, _) => ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _actions(theme),
              if (_c.started) ...[
                const SizedBox(height: 16),
                _progress(theme),
                const SizedBox(height: 12),
                _logBox(),
              ],
              if (_c.finished) ...[
                const SizedBox(height: 16),
                _c.succeeded ? _success(theme) : _failure(theme),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- parts

  Widget _actions(ThemeData theme) {
    final hasLast = widget.project.runId != null;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(widget.project.fullName,
                textDirection: TextDirection.ltr, style: theme.textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(statusLabel(widget.project.status), style: theme.textTheme.bodySmall),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _c.busy ? null : _pickAndBuild,
              icon: const Icon(Icons.folder_zip),
              label: const Text('اختيار ملف ZIP وبدء التجميع'),
            ),
            if (_c.busy) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: _c.cancel,
                icon: const Icon(Icons.stop_circle_outlined),
                label: const Text('إلغاء التجميع'),
              ),
            ] else if (hasLast && !_c.started) ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: _c.showLast,
                icon: const Icon(Icons.history),
                label: const Text('عرض نتيجة آخر تجميع'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _progress(ThemeData theme) {
    final value = _c.progress;
    final percent = value == null ? '' : '${(value * 100).round()}%';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                _c.stage.isEmpty ? '...' : _c.stage,
                style: theme.textTheme.titleSmall,
              ),
            ),
            Text(percent, style: theme.textTheme.labelLarge),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: LinearProgressIndicator(
            minHeight: 8,
            value: _c.busy && value == null ? null : value,
          ),
        ),
      ],
    );
  }

  Widget _logBox() {
    return Container(
      height: 260,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF0F172A),
        borderRadius: BorderRadius.circular(12),
      ),
      child: _c.logs.isEmpty
          ? const SizedBox.shrink()
          : ListView.builder(
              controller: _logScroll,
              itemCount: _c.logs.length,
              itemBuilder: (_, i) {
                final line = _c.logs[i];
                Color color = const Color(0xFFE2E8F0);
                if (line.contains('✗')) {
                  color = const Color(0xFFFCA5A5);
                } else if (line.contains('✓')) {
                  color = const Color(0xFF86EFAC);
                } else if (line.contains('▶')) {
                  color = const Color(0xFF93C5FD);
                }
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                    line,
                    style: TextStyle(fontFamily: 'monospace', fontSize: 12.5, color: color),
                  ),
                );
              },
            ),
    );
  }

  Widget _success(ThemeData theme) {
    final file = _c.apkFile;
    final name = file == null ? '' : file.uri.pathSegments.last;
    return Card(
      color: theme.colorScheme.primaryContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.green, size: 32),
                const SizedBox(width: 12),
                Expanded(
                  child: Text('تم إنشاء ملف APK بنجاح',
                      style: theme.textTheme.titleMedium),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(name, textDirection: TextDirection.ltr),
            if (_c.apkBytes != null) Text(formatSize(_c.apkBytes!)),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _install,
              icon: const Icon(Icons.install_mobile),
              label: const Text('تثبيت التطبيق'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: file == null ? null : () => _copy(file.path, 'تم نسخ مسار الملف'),
              icon: const Icon(Icons.copy),
              label: const Text('نسخ مسار الملف'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _failure(ThemeData theme) {
    final summary = _c.errorSummary ?? 'فشل التجميع';
    final log = _c.errorLog;
    return Card(
      color: theme.colorScheme.errorContainer,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(Icons.error, color: theme.colorScheme.error, size: 32),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(summary,
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: theme.colorScheme.onErrorContainer,
                      )),
                ),
              ],
            ),
            if (log != null && log.isNotEmpty) ...[
              const SizedBox(height: 12),
              Container(
                constraints: const BoxConstraints(maxHeight: 320),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F172A),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: SingleChildScrollView(
                  child: Directionality(
                    textDirection: TextDirection.ltr,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: SelectableText(
                        log,
                        style: const TextStyle(
                          fontFamily: 'monospace',
                          fontSize: 12,
                          color: Color(0xFFE2E8F0),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () => _copy(log, 'تم نسخ سجل الخطأ'),
                icon: const Icon(Icons.copy),
                label: const Text('نسخ سجل الخطأ'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

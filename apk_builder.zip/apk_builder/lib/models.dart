class Project {
  Project({
    required this.name,
    required this.owner,
    this.branch = 'main',
    this.status = 'created',
    this.runId,
  });

  final String name;
  final String owner;
  String branch;

  /// created | building | success | failure
  String status;
  int? runId;

  String get fullName => '$owner/$name';
  String get url => 'https://github.com/$owner/$name';

  Map<String, dynamic> toJson() => {
        'name': name,
        'owner': owner,
        'branch': branch,
        'status': status,
        'runId': runId,
      };

  factory Project.fromJson(Map<String, dynamic> j) => Project(
        name: j['name'] as String,
        owner: j['owner'] as String,
        branch: (j['branch'] as String?) ?? 'main',
        status: (j['status'] as String?) ?? 'created',
        runId: (j['runId'] as num?)?.toInt(),
      );
}

String statusLabel(String status) {
  switch (status) {
    case 'building':
      return 'جارٍ التجميع';
    case 'success':
      return 'نجح التجميع';
    case 'failure':
      return 'فشل التجميع';
    default:
      return 'بانتظار ملف ZIP';
  }
}

String formatSize(int bytes) => '${(bytes / 1048576).toStringAsFixed(1)} MB';

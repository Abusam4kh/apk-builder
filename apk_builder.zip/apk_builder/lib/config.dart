class AppConfig {
  AppConfig._();

  /// يُمرَّر وقت البناء: --dart-define=GH_CLIENT_ID=xxxx
  /// وإن كان فارغاً يطلبه التطبيق من المستخدم مرة واحدة ويحفظه.
  static const String definedClientId = String.fromEnvironment('GH_CLIENT_ID');

  /// صلاحيات التوكن: repo لإنشاء المستودع ورفع الملفات، workflow لإنشاء ملف الـ workflow.
  static const String scope = 'repo workflow';

  static const String zipPath = 'project.zip';
  static const String workflowFile = 'build-apk.yml';
  static const String workflowPath = '.github/workflows/build-apk.yml';

  /// حدّ حجم ملف ZIP (واجهة GitHub تقبل حتى 100MB، نترك هامش أمان).
  static const int maxZipBytes = 50 * 1024 * 1024;
}

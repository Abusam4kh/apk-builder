import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'screens/home_screen.dart';
import 'screens/login_screen.dart';
import 'services/auth_service.dart';

void main() => runApp(const ApkBuilderApp());

class ApkBuilderApp extends StatelessWidget {
  const ApkBuilderApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF2563EB);
    return MaterialApp(
      title: 'بنّاء APK',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      theme: ThemeData(colorSchemeSeed: seed, useMaterial3: true),
      darkTheme: ThemeData(
        colorSchemeSeed: seed,
        useMaterial3: true,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const Gate(),
    );
  }
}

/// يقرّر: شاشة تسجيل الدخول (أول مرة فقط) أو القائمة الرئيسية.
class Gate extends StatefulWidget {
  const Gate({super.key});

  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  final AuthService _auth = AuthService();
  Session? _session;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final s = await _auth.loadSession();
    if (!mounted) return;
    setState(() {
      _session = s;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final session = _session;
    if (session == null) {
      return LoginScreen(
        auth: _auth,
        onLoggedIn: (s) => setState(() => _session = s),
      );
    }
    return HomeScreen(
      session: session,
      onLogout: () async {
        await _auth.clear();
        if (mounted) setState(() => _session = null);
      },
    );
  }
}
